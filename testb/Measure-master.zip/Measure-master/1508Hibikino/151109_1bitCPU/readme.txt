Ch1: CLK
Ch2: IN
Ch3: OUT

measure1.png : IN=0
measure2.png : IN=1

